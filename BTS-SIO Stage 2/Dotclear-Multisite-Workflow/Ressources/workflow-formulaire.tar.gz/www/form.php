<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
	$hostname = "localhost";
	$username = "dotclearuser";
	$password = "cleardotstage";
	$database = "dotclear";
	$sql_connect = new MySQLi($hostname, $username, $password, $database);
	$secret = "35orfgi2=-7#%g43kl";


function validate_email($email){
   $mailparts=explode("@",$email);
   $hostname = $mailparts[1];

   // validate email address syntax
   $exp = "^[a-z\'0-9]+([._-][a-z\'0-9]+)*@([a-z0-9]+([._-][a-z0-9]+))+$";
   $b_valid_syntax=eregi($exp, $email);

   // get mx addresses by getmxrr
   $b_mx_avail=getmxrr( $hostname, $mx_records, $mx_weight );
   $b_server_found=0;

   if($b_valid_syntax && $b_mx_avail){
     // copy mx records and weight into array $mxs
     $mxs=array();

     for($i=0;$i<count($mx_records);$i++){
       $mxs[$mx_weight[$i]]=$mx_records[$i];
     }

     // sort array mxs to get servers with highest prio
     ksort ($mxs, SORT_NUMERIC );
     reset ($mxs);

     while (list ($mx_weight, $mx_host) = each ($mxs) ) {
       if($b_server_found == 0){

         //try connection on port 25
         $fp = @fsockopen($mx_host,25, $errno, $errstr, 2);
         if($fp){
           $ms_resp="";
           // say HELO to mailserver
           $ms_resp.=send_command($fp, "HELO");

             $b_server_found=1;

           // quit mail server connection
           $ms_resp.=send_command($fp, "QUIT");

         fclose($fp);

         }

       }
    }
  }
  return $b_server_found;
}

function send_command($fp, $out){

  fwrite($fp, $out . "\r\n");
  return get_data($fp);
}

function get_data($fp){
  $s="";
  stream_set_timeout($fp, 2);

  for($i=0;$i<2;$i++)
    $s.=fgets($fp, 1024);

  return $s;
}

function is_valid_domain_name($domain_name)
{
    return (preg_match("/^([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*$/i", $domain_name) //valid chars check
            && preg_match("/^.{1,253}$/", $domain_name) //overall length check
            && preg_match("/^[^\.]{1,63}(\.[^\.]{1,63})*$/", $domain_name)   ); //length of each label
}
function securite_bdd($string)
{
	if(ctype_digit($string))
	{
		$string = intval($string);
	}
	else
	{
		$string = addcslashes($string, '%_');
		$string = stripslashes($string);
		$string = strip_tags($string);
		$string = trim($string," ");
		$string = implode("",explode("\\",$string));
		$string = filter_var($string ,FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW | FILTER_FLAG_STRIP_HIGH);
	}
	return stripslashes(trim($string));
}
function securite_form($string)
{
		$string = addcslashes($string, '%_');
		//$string = addslashes($string);
		//$string = stripslashes($string);
		$string = strip_tags($string);
		$string = trim($string," ");
		$string = implode("",explode("\\",$string));
		$string = filter_var($string ,FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
	return trim($string);
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Formulaire | leWeb.in</title>
        <link rel='stylesheet' type='text/css' href="css/bootstrap.min.css" />
        <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,700' />
        <link rel='stylesheet' type='text/css' href="css/styles.css" />
        <!--[if lt IE 9]>
            <script src="js/hml5shiv.min.js"></script>
        <![endif]-->

        <!--[if lt IE 10]>
            <script src="js/h5f.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div class="container">
            <div class="row header">
                <div class="col-md-4 col-left">&nbsp;</div>
                <div class="col-md-8 col-right">
                    <div class="logo">
                        <a href="/"><img src="img/logo.png" /></a>
                    </div>
                </div>
            </div>
            <div class="row descriptif">
                <div class="">
<!--
                    <div class="col-sm-4 col-md-4 col-left">
                        <div class="deco">&nbsp;</div>
                    </div>
-->
                    <div class="col-sm-8 col-sm-offset-4 col-md-8 col-md-offset-4 col-right">
                        <div class="descriptif-text">
                            <p class="slogan">LeWeb.in&nbsp;est&nbsp;une&nbsp;solution&nbsp;<span class="vraiment"><img src="img/vraiment.png"></span> gratuite de cr&eacute;ation de site web <br /> r&eacute;serv&eacute;e aux associations Loi 1901.</p>
                            <div class="row nombres">
                                <div class="col-sm-4">
                                    <p>
                                        <span>1</span></p>
                                    <p>
                                        Inscrivez-vous</p>
                                </div>
                                <div class="col-sm-4">
                                    <p>
                                        <span>2</span></p>
                                    <p>
                                        Cr&eacute;ez votre site</p>
                                </div>
                                <div class="col-sm-4">
                                    <p>
                                        <span>3</span></p>
                                    <p>
                                        Partagez !</p>
                                </div>
                            </div>
                            <p class="small">&nbsp;</p>
                            <p class="small">
                                LeWeb.in est une solution d&eacute;ploy&eacute;e par <a href="http://www.artefact.fr" title="Agence Web Artefact">Artefact</a> et h&eacute;berg&eacute;e dans le datacenter <a href="http://www.arteone.fr" title="Datacenter ArteOne Brive, Correze">Arteone</a>.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 col-left hidden-xs">
                    <div class="teaser voiraussi">
                        <img src="img/voiraussi.png" />
                    </div>
                    <div class="teaser biosign">
                        <a href="http://www.leweb.bio"><img src="img/biosign.png" /></a>
                    </div>
                    <div class="teaser correze">
                        <p>&nbsp;</p>
                        <img src="img/correze.png" />
                    </div>
                </div>
                <div class="col-sm-8 col-md-8 col-right no-padding">
			<?php
		if(isset($_GET['mail']) && !empty($_GET['mail'])){
		$mailval = urldecode($_GET['mail']);
		if (md5($mailval.$secret) == $_GET['hash']) {

				$reqvalmail = "UPDATE dc_demands SET val_mail=1 WHERE dc_demands.Mail='$mailval';";
				$resvalmail = mysqli_query($sql_connect,$reqvalmail);
				?>
				<br />
				<span class="phpinfo">
				<span class="valid">Votre Mail a bien &eacute;t&eacute; v&eacute;rifi&eacute;. Un administrateur validera votre demande, vous recevrez un e-mail de validation contenant tous les d&eacute;tails de votre espaxe WEB.</span>
				</span>
				<?php
				die();
			}
			}
			 if ((!isset($_POST['domain']) && empty($_POST['domain'])) && (!isset($_POST['mail']) && empty($_POST['mail']))){
                    ?>
			<div class="form">
                        <div class="row">
                            <div class="col-sx-12 col-sm-8 col-sm-offset-3">
                                <p class="form-title">
                                    <span class="chiffre">1</span> Inscrivez-vous
                                </p>
                            </div>
                        </div>
                        <form action="index.php" method="post" data-toggle="validator" role="form" >
                            <div class="form-group row">
                                <label class="col-sm-3 control-label">Votre nom</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="firstname" placeholder="Nom du pr&eacute;sident de l'association" data-minlength="3" required />
                                    <span class="help-block">Le nom est un champ obligatoire.</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 control-label">Votre pr&eacute;nom</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="lastname" placeholder="Pr&eacute;nom du pr&eacute;sident de l'association" data-minlength="3" required />
                                    <span class="help-block">Le pr&eacute;nom est un champ obligatoire.</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 control-label">Association</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="association" placeholder="Nom de l'association" data-minlength="3" required />
                                    <span class="help-block">Le nom d'association est un champ obligatoire.</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 control-label">Num&eacute;ro RNA/Waldec</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="declaration" placeholder="Num&eacute;ro de déclaration au J.O." data-minlength="10" maxlength="10" required />
                                    <span class="help-block">Le num&eacute;ro de declaration est un champ obligatoire.</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 control-label">Adresse</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="address" placeholder="Adresse du si&egrave;ge de l'association" data-minlength="3" required />
                                    <span class="help-block">L'adresse du si&egrave;ge de l'association est obligatoire.</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 control-label">T&eacute;l&eacute;phone</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="phone" placeholder="T&eacute;l&eacute;phone" pattern="^([0-9])+$" data-minlength="10" maxlength="12" required />
                                    <span class="help-block">Le numero de telephone est obligatoire.</span>
                                </div>
                            </div>
							<div class="form-group row">
                                <label class="col-sm-3 control-label">Nom de domaine</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="domain" placeholder="Nom de Domaine souhait&eacute;" data-minlength="5" data-maxlength="100" required />
                                    <span class="help-block">Le nom de domaine est obligatoire.</span>
                                </div>
                            </div>
							<div class="form-group row">
                                <label class="col-sm-3 control-label">Adresse Mail</label>
                                <div class="col-sm-8">
                                    <input type="email" class="form-control" name="mail" placeholder="Votre adresse mail" data-minlength="5" data-maxlength="100" required />
                                    <span class="help-block">Une adresse Mail est obligatoire.</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-11 text-right">
                                    <button type="submit" class="btn btn-default btn-green">S'INSCRIRE</button>
                                </div>
                            </div>
                        </form>
               <?php
		}
				if ((isset($_POST['domain']) && !empty($_POST['domain'])) && (isset($_POST['mail']) && !empty($_POST['mail']))){
					$domain = securite_bdd($_POST['domain']);
					$domain = strtolower($domain);
					$domain = mysqli_real_escape_string($sql_connect,$domain);
					$domain = str_replace('www.','',$domain);
					$domain = str_replace("'","",$domain);
					$domain = strtr($domain, "àâäçéèêëîïùüû", "aaaceeeeiiuuu");
					$domain = 'www.'.$domain;
					$mail = $_POST['mail'];
					if(filter_var($mail, FILTER_VALIDATE_EMAIL)){
					if(validate_email($mail)){
					?>
					<br />
					<span class="phpinfo">
					<?php
					if (isset($_POST['phone']) && isset($_POST['address']) && isset($_POST['declaration']) && isset($_POST['association']) && isset($_POST['lastname']) && isset($_POST['firstname'])) {
					if (is_valid_domain_name($domain)) {
					$phone=$_POST['phone'];
					$address=securite_form($_POST['address']);
					$declaration=securite_form($_POST['declaration']);
					$assoc=securite_form($_POST['association']);
					$lastname=securite_form($_POST['lastname']);
					$firstname=securite_form($_POST['firstname']);
					$demand_date = date("Y-m-d H:i:s");
					$validated = 0;
					$val_mail = 0;
					$type = 'Association';

					$reqverifmail="SELECT Mail FROM dc_demands WHERE Mail='$mail';";
					$resultverifmailsql = mysqli_query($sql_connect,$reqverifmail);
					$convertedresultverifmail = mysqli_fetch_assoc($resultverifmailsql);
					if ($convertedresultverifmail['Mail'] == $mail){
						echo "Ce Mail a déjà &eacute;t&eacute; utilis&eacute; <br />";
						die();
						}
					$reqverifdom="SELECT Domain FROM dc_demands WHERE domain='$domain';";
					$resultverifdomsql = mysqli_query($sql_connect,$reqverifdom);
					$convertedresultverifdom = mysqli_fetch_assoc($resultverifdomsql);
					if ($convertedresultverifdom['Domain'] == $domain){
						echo "Ce domaine '$domain' a déjà &eacute;t&eacute; reserv&eacute;<br />";
						die();
						}
						else
						{
						$reqdemand="INSERT INTO dc_demands (type,name,Subname,Association,Adress,Telephone,Domain,Declaration,Mail,val_mail,Validated,date) VALUES ('$type','$lastname','$firstname','$assoc','$address','$phone','$domain','$declaration','$mail',$val_mail,$validated,'$demand_date');";
						$sqldemand = mysqli_query($sql_connect,$reqdemand);
						//Verification mail
						$mailenc = urlencode($mail);
						$hash = MD5($mail.$secret);
						$link = "http://leweb.in/form.php?mail=$mailenc&hash=$hash";
						// Envoi mail
                                $ipserv = '193.104.36.130';

                                if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $mail)) // On filtre les serveurs qui rencontrent des bogues.
                                {
                                        $ligne = "\r\n";
                                }
                                else
                                {
                                        $ligne = "\n";
                                }

                                $message_txt = 'Bonjour ' . $lastname . ' ' . $firstname . ',' . $ligne . ' Votre demande de cr&eacute;ation d\'espace WEB a bien &eacute;t&eacute; prise en compte.' . $ligne . 'Afin de v&eacute;rifier votre adresse mail, veuillez cliquer sur ce lien : ' . $ligne . ' ' . $link . ' ' . $ligne . 'Cordialement, l\'&eacute;quipe Artefact.';
                                $message_html = '<html><head></head><body>Bonjour ' . $lastname . ' ' . $firstname . ',<br />' . $ligne . ' Votre demande de cr&eacute;ation d\'espace WEB a bien &eacute;t&eacute; prise en compte.<br />' . $ligne . 'Afin de v&eacute;rifier votre adresse mail, veuillez cliquer sur le lien :<br />' . $ligne . ' ' . $link . '<br /> ' . $ligne . '<i>Cordialement, l\'&eacute;quipe Artefact.</i></body></html>';

                                $bon = "-----=".md5(rand());

                                $sujet = utf8_decode('Vérification e-mail pour la demande d\'espace WEB pour '.$domain.'');

                                $header = "From: \"Artefact LeWEB\"<leweb@artefact.fr>".$ligne;
                                $header.= "Reply-to: \"Artefact LeWEB\" <leweb@artefact.fr>".$ligne;
                                $header.= "MIME-Version: 1.0".$ligne;
                                $header.= "Content-Type: multipart/alternative; ".$ligne." boundary=\"$bon\"".$ligne;

                                $message = $ligne."--".$bon.$ligne;

                                $message.= "Content-Type: text/plain; charset=\"utf-8\"".$ligne;
                                $message.= "Content-Transfer-Encoding: 8bit".$ligne;
                                $message.= $ligne.$message_txt.$ligne;

                                $message.= $ligne."--".$bon.$ligne;

                                $message.= "Content-Type: text/html; charset=\"utf-8\"".$ligne;
                                $message.= "Content-Transfer-Encoding: 8bit".$ligne;
                                $message.= $ligne.$message_html.$ligne;

                                $message.= $ligne."--".$bon."--".$ligne;
                                $message.= $ligne."--".$bon."--".$ligne;

                                mail($mail, $sujet, $message, $header);

						?>
						<span class="valid">
                                        	<?php
						echo "Votre demande pour '$domain' &agrave; bien &eacute;t&eacute; prise en compte. Vérifiez vos mails, un lien de confirmation de mail vous a &eacute;t&eacute; envoy&eacute;";
						echo "<br />";
						echo $link;
						?>
						</span>
						<?php
						}
					}
					else
					{
					echo "La syntaxe de votre domaine n'est pas correcte.";
					}
					}
					else
					{
					echo "Le formulaire n'a pas &eacute;t&eacute; correctement rempli.";
					}
				?>
				<?php
				}
				else
				{
				?>
				<span class="phpinfo">
                                <?php
                                echo "L'adresse mail utilis&eacute;e n'&eacute;xiste pas.";
                                ?>
                                </span>
                                <?php
				}
				}
				else
				{
				?>
				<span class="phpinfo">
				<?php
				echo "Le mail est incorrect";
				?>
				</span>
				<?php
				}
				?>
				</span>
				<?php
				}
				?>
			</div>
		</div>
                <div class="col-md-4 col-sm-4 col-left show-xs">
                    <div class="teaser voiraussi">
                        <img src="img/voiraussi.png" />
                    </div>
                    <div class="teaser biosign">
                        <a href="http://www.leweb.bio"><img src="img/biosign.png" /></a>
                    </div>
                    <div class="teaser correze">
                        <p>&nbsp;</p>
                        <img src="img/correze.png" />
                    </div>
                </div> 
            </div>
        </div>
        
        <script src="js/jquery.min.js"></script>
        <script>
                        (function($){

                            $(document).ready(function(){

                                var asso = function(e,a) { 
                                    var val = $(this).val(); 
                                    $('input[name="domain"]').val( val.replace(/[^a-z0-9]/gi,'') + '.leweb.in' ); 
                                }

                                $('input[name="association"]').change(asso).blur(asso);

                            });

                        })(jQuery)
                    </script>
        <script src="js/bootstrap.min.js"></script>
        
        <script src="js/validator.min.js"></script>
        
        <script src="js/scripts.js"></script>
    </body>
</html>
