<?php
//Fonction de test du domaine
function is_valid_domain_name($domain_name)
{
	return (preg_match("/^([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*$/i", $domain_name)
			&& preg_match("/^.{1,253}$/", $domain_name)
			&& preg_match("/^[^\.]{1,63}(\.[^\.]{1,63})*$/", $domain_name));
}

//Recuperation id_demand formulaire
$iddemand = $_POST['id_demand'];
//SQL pour recup domain et Mail
$reqdomain="SELECT Domain,Mail,name,Subname,date FROM dc_demands WHERE id_demand='$iddemand';";
$result_domain = mysqli_query($sql_connect,$reqdomain);
$rowdemand = mysqli_fetch_array($result_domain,MYSQLI_ASSOC);
$domain = $rowdemand['Domain'];
$mail = $rowdemand['Mail'];
$name = $rowdemand['name'];
$sname = $rowdemand['Subname'];
$datedem = $rowdemand['date'];

//recuperation information domaine
if (isset($domain) && !empty($domain)) {
	$domain = strtolower($domain);
	$domain = mysqli_real_escape_string($sql_connect,$domain);
	$domain = str_replace('www.','',$domain);
	$domain = 'www.'.$domain;
	if ($sql_connect->connect_error) {
		echo "Non connecté à la base de donnée <br />";
		die();
	}
	else {
		//Comparaison du domaine vers la table BadWords
		$reqwords = "SELECT words FROM dc_badwords WHERE words='$domain';";
		$resultwords = mysqli_query($sql_connect,$reqwords);
		if (mysqli_num_rows($resultwords) < 1)
		{
			//Filtrage des infos > domain_blogs
			if (is_valid_domain_name($domain)) {
				echo "La forme du domaine est valide, le travail continue <br />";

				if(filter_var($mail, FILTER_VALIDATE_EMAIL)){
				//Generation du Blog_id
				$idblog = $domain;
				$idblog = str_replace('.', '', $idblog);


				//Generation d'un MD5 HEX 32 Bits pour blog_uid du blog
				$uidblog = md5($idblog);

				//Generation de date de creation blog_datecrea
				$creablogdt = date("Y-m-d H:i:s");

				//Generation blog_URL
				$blogurl = 'http:/\/'.$domain.'/index.php?';
				$admurl = 'http:/\/'.$domain.'/admin/';
				// Variable anti commentaire PHP
				$admurlmail = 'http:/';
				$admurlmail .= '/';
				$admurlmail .= $domain;
				$admurlmail .= '/admin/';
				//Variable Anti commentaire PHP
				$blogurlmail = 'http:/';
				$blogurlmail .= '/';
				$blogurlmail .= $domain;
				$blogurlmail .= '/index.php';

				//Generation du blog_name
				$blogname = $domain.' blog';

				//Generation de la description du blog_desc
				$blogdesc = 'Ceci est le blog '.$domain ;

				//Verifications if_empty isset des variables generes
				if ((isset($idblog) && !empty($idblog)) && (isset($uidblog) && !empty($uidblog)) && (isset($creablogdt) && !empty($creablogdt)) && (isset($blogurl) && !empty($blogurl)) && (isset($blogname) && !empty($blogname)) && (isset($blogdesc) && !empty($blogdesc)))
				{
					//Verification et remplacement des caractères slashs, anti-slashs et pipe
					if ((strpos($domain, '&#47;') !== false) && (strpos($domain, '&#92;') !== false) && (strpos($domain, '&#124;') !== false)) {
					$domain = str_replace('&#37;', '', $domain);
					$domain = str_replace('&#92;', '', $domain);
					$domain = str_replace('&#124;', '', $domain);
					}
					//Requêtes SQL
					$reqverif="SELECT blog_id FROM dc_blog WHERE blog_id='$idblog';";
					$req="INSERT INTO dc_blog (blog_id,blog_uid,blog_creadt,blog_upddt,blog_url,blog_name,blog_desc,blog_status) VALUES ('$idblog','$uidblog','$creablogdt','$creablogdt','$blogurl','$blogname','$blogdesc',1);";
					$reqpublic="INSERT INTO dc_setting VALUES ('public_path','$idblog','system','$idblog/public','string','Path to public directory');";
					$reqpublicurl="INSERT INTO dc_setting VALUES ('public_url','$idblog','system','/$idblog/public','string','URL to public directory');";
					//Requete modification validated dc_demands
					$reqdemandval="UPDATE dc_demands SET Validated=1 WHERE dc_demands.id_demand=$iddemand;";
					//Exécution SQL de verif
					$resultverifsql = mysqli_query($sql_connect,$reqverif);
					$convertedresultverif = mysqli_fetch_assoc($resultverifsql);
						if ($convertedresultverif['blog_id'] == $idblog){
						echo "Le domaine '$idblog' a déjà été enregistré <br />";
						die();
					}
					else
					{
					//Executions SQL
					$result_sql = mysqli_query($sql_connect,$req);
					$result_sqlpublic = mysqli_query($sql_connect,$reqpublic);
					$result_sqlpublicurl = mysqli_query($sql_connect,$reqpublicurl);
					//Execution SQL dc_demands
					$result_sqldemandval = mysqli_query($sql_connect,$reqdemandval);
					echo "Le Blog a bien été crée dans notre base de donnée";
					}
				}
				else
				{
				echo "Erreurs dans la génération des variables";
				die();
				}
				//Creation de l'user
				$userid = $mail;

				// Test name user exists
				$reqverifuser="SELECT user_id FROM dc_user WHERE user_id='$userid';";
				$resultverifusersql = mysqli_query($sql_connect,$reqverifuser);
				$convertedresultverifuser = mysqli_fetch_assoc($resultverifusersql);
                                if ($convertedresultverifuser['user_id'] == $userid){
					echo "Cet utilisateur DotClear existes déjà";
					die();
				}

				//Creation du pass + cryptage
				require dirname(__FILE__).'/../inc/admin/prepend.php';
				include("../inc/libs/clearbricks/common/lib.crypt.php");
				include("../inc/config.php");

				$pass = crypt::createPassword();
				$pass_crypt = crypt::hmac(DC_MASTER_KEY,$pass);
				//Preparation des requetes
				$requseradd="INSERT INTO dc_user (user_id,user_super,user_status,user_pwd,user_change_pwd,user_lang,user_tz,user_post_status,user_creadt,user_upddt) VALUES ('$userid',0,1,'$pass_crypt',0,'fr','Europe/Paris',-2,'$creablogdt','$creablogdt');";
				$requseraddperm="INSERT INTO dc_permissions VALUES ('$userid','$idblog','|admin|');";

				//Execution des requetes
				$result_sqluseradd = mysqli_query($sql_connect,$requseradd);
				$result_sqluseraddperm = mysqli_query($sql_connect,$requseraddperm);
				//Affichage  des informations
				echo "<br />";
				echo "Utilisateur admin : ";
				echo $userid;
				echo "<br />";
				echo "Mot de passe admin : ";
				echo $pass;
				//Envoi des informations

				//Execution du Script Bash
				echo "<br />";
				echo "<hr />";
				chdir('/var/www-scripts/');
				$output = shell_exec('./newblog.sh '.$domain.' '.$idblog);
				echo $output;

				// Envoi du mail au client
				$ipserv = '193.104.36.130';

				if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $mail)) // On filtre les serveurs qui rencontrent des bogues.
				{
					$ligne = "\r\n";
				}
				else
				{
					$ligne = "\n";
				}

				$message_txt = 'Bonjour ' . $name . ' ' . $sname . ',' . $ligne . ' Votre demande de cr&eacute;ation d\'espace WEB datant du ' . $datedem . ' viens d\'&ecirc;tre accept&eacute;e par un Administrateur.' . $ligne . 'Voici les informations concernant votre nouvel espace :' . $ligne . ' Identifiant admin :' . $userid . $ligne . ' Mot de passe Admin : ' . $pass . $ligne . 'Espace Administrateur : ' . $admurlmail . $ligne . 'Espace WEB : ' . $blogurlmail . $ligne . ' Si vous &ecirc;tes le propri&eacute;taire du domaine ' . $domain . ' , faites-le pointer sur ' . $ipserv . '.' . $ligne . 'Cordialement, l\'&eacute;quipe Artefact.';
				$message_html = '<html><head></head><body>Bonjour ' . $name . ' ' . $sname . ',<br />' . $ligne . ' Votre demande de cr&eacute;ation d\'espace WEB datant du ' . $datedem . ' viens d\'&ecirc;tre accept&eacute;e par un Administrateur.<br />' . $ligne . 'Voici les informations concernant votre nouvel espace :<br /><br />' . $ligne . ' Identifiant admin :<b>' . $userid . $ligne . '</b><br /> Mot de passe Admin : <b>' . $pass . $ligne . '</b><br />Espace Administrateur : <b>' . $admurlmail . $ligne . '</b><br />Espace WEB : <b>' . $blogurlmail . $ligne . '</b><br /> Si vous &ecirc;tes le propri&eacute;taire du domaine <b>' . $domain . '</b>, faites-le pointer sur ' . $ipserv . '.<br /> <i>Cordialement, l\'&eacute;quipe Artefact.</i></body></html>';

				$bon = "-----=".md5(rand());

				$sujet = utf8_decode('Demande d\'espace WEB validée pour '.$domain.'');

				$header = "From: \"Artefact LeWEB\"<leweb@artefact.fr>".$ligne;
				$header.= "Reply-to: \"Artefact LeWEB\" <leweb@artefact.fr>".$ligne;
				$header.= "MIME-Version: 1.0".$ligne;
				$header.= "Content-Type: multipart/alternative; ".$ligne." boundary=\"$bon\"".$ligne;

				$message = $ligne."--".$bon.$ligne;

				$message.= "Content-Type: text/plain; charset=\"utf-8\"".$ligne;
				$message.= "Content-Transfer-Encoding: 8bit".$ligne;
				$message.= $ligne.$message_txt.$ligne;

				$message.= $ligne."--".$bon.$ligne;

				$message.= "Content-Type: text/html; charset=\"utf-8\"".$ligne;
				$message.= "Content-Transfer-Encoding: 8bit".$ligne;
				$message.= $ligne.$message_html.$ligne;

				$message.= $ligne."--".$bon."--".$ligne;
				$message.= $ligne."--".$bon."--".$ligne;

				mail($mail, $sujet, $message, $header);
				echo '<br />';
				echo '<hr />';
				echo 'Le mail de recap a &eacute;t&eacute; envoyé à l\'adresse mail : ' . $mail;
				}
				else
				{
				echo "Le mail que vous avez rentré est invalide ou mal formulé";
				die();
				}

			}
			else
			{
				echo "Le domaine que vous avez rentré est invalide ou mal formulé";
				die();
			}
		}
		else
		{
		echo "Votre domaine comprends des mots interdits par nos services";
		die();
		}
	}
}
else
{
	echo "Vous n'avez pas rentré de domaine dans le précédent formulaire";
	die();
}
?>
