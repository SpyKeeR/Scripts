﻿<!DOCTYPE html>
<?php
header('Content-Type: text/html; charset=utf-8');

	$hostname = "localhost";
	$username = "dotclearuser";
	$password = "cleardotstage";
	$database = "dotclear";
	$sql_connect = new MySQLi($hostname, $username, $password, $database);

function securite_bdd($string)
{
	if(ctype_digit($string))
	{
		$string = intval($string);
	}
	else
	{
		$string = addcslashes($string, '%_');
		$string = stripslashes($string);
		$string = strip_tags($string);
		$string = trim($string," ");
		$string = implode("",explode("\\",$string));
		$string = filter_var($string ,FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW | FILTER_FLAG_STRIP_HIGH);
	}
	return stripslashes(trim($string));
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Panel Admin - Gestion des demandes de blog</title>
	</head>
	<body>
	<center>
<?php
$reqselect = "SELECT * FROM dc_demands WHERE dc_demands.val_mail=1 ORDER BY type ASC,Association ASC,Validated ASC;";
$resultselect = mysqli_query($sql_connect, $reqselect);
if(mysqli_num_rows($resultselect) > 0) {
?>
    <div style="min-height:450px;height:450px;overflow:auto;">
<h1>Liste de toutes les demandes de blogs :</h1>
	<table>
             <tr>
                    <th width=55 bgcolor="#008E8E">Type</th>
                    <th width=55 bgcolor="#008E8E">ID</th>
                    <th width=119 bgcolor="#008E8E">Nom</th>
                    <th width=119 bgcolor="#008E8E">Prénom</th>
                    <th width=119 bgcolor="#008E8E">Association / Entreprise</th>
                    <th width=119 bgcolor="#008E8E">Adresse</th>
                    <th width=90 bgcolor="#008E8E">Téléphone</th>
                    <th width=149 bgcolor="#008E8E">Nom de Domaine</th>
                    <th width=90 bgcolor="#008E8E">Mail</th>
                    <th width=119 bgcolor="#008E8E">SIREN</th>
                    <th width=119 bgcolor="#008E8E">Déclaration</th>
                    <th width=55 bgcolor="#008E8E">Validé</th>
                    <th width=149 bgcolor="#008E8E">Date de la demande</th>
                </tr>
            <?php
while($rowsel = mysqli_fetch_array($resultselect,MYSQLI_ASSOC)) {
?>    
<tr>
    <td align="center" width=55 bgcolor="#EFEFEF"><?php echo $rowsel["type"] ?></td>
    <td align="center" width=55 bgcolor="#EFEFEF"><?php echo $rowsel["id_demand"] ?></td>
    <td align="center" width=119 bgcolor="#EFEFEF"><?php echo $rowsel["name"] ?></td>
    <td align="center" width=119 bgcolor="#EFEFEF"><?php echo $rowsel["Subname"] ?></td>
    <td align="center" width=119 bgcolor="#EFEFEF"><?php echo $rowsel["Association"] ?></td>
    <td align="center" width=119 bgcolor="#EFEFEF"><?php echo $rowsel["Adress"] ?></td>
    <td align="center" width=90 bgcolor="#EFEFEF"><?php echo $rowsel["Telephone"] ?></td>
    <td align="center" width=149 bgcolor="#EFEFEF"><?php echo $rowsel["Domain"] ?></td>
    <td align="center" width=149 bgcolor="#EFEFEF"><?php echo $rowsel["Mail"] ?></td>
    <td align="center" width=149 bgcolor="#EFEFEF"><?php echo $rowsel["SIREN"] ?></td>
    <td align="center" width=119 bgcolor="#EFEFEF"><?php echo $rowsel["Declaration"] ?></td>
    <td align="center" width=55 bgcolor="#EFEFEF"><?php echo $rowsel["Validated"] ?></td>
    <td align="center" width=149 bgcolor="#EFEFEF"><?php echo $rowsel["date"] ?></td>
</tr>
<?php
}
?>
</table>
<?php
}
else {
	echo 'Pas d\'enregistrements dans la table des demandes de cr&eacute;ation de blogs...';
	}
?>
</div>

<hr />
<h1>Selection des demandes non validées à valider : </h1>

<?php

if(mysqli_num_rows($resultselect) > 0) {
$reqselectval = "SELECT type,id_demand,name,Subname,Association,Domain,Mail FROM dc_demands WHERE Validated=0 AND val_mail=1 ORDER BY type ASC,Association ASC;";
$resultselectval = mysqli_query($sql_connect, $reqselectval);
?>
<form action="admin.php" method="post">
<select name="id_demand">
<?php
while($rowselval = mysqli_fetch_array($resultselectval,MYSQLI_ASSOC)) {
?>
<option value="<?php echo $rowselval['id_demand']; ?>"><?php echo $rowselval['type']; ?> | <?php echo $rowselval['name']; ?> <?php echo $rowselval['Subname']; ?> | <?php echo $rowselval['Association']; ?> | <?php echo $rowselval['Domain']; ?> | <?php echo $rowselval['Mail']; ?></option>
<?php
}
?>
</select>
<button type="submit">Valider la demande</button>
</form>
<?php
if (isset($_POST['id_demand']) && !empty($_POST['id_demand'])) {
include 'newblog.php';
}
}
else
{
echo 'Pas d\'enregistrements dans la table des demandes de cr&eacute;ation de blogs...';
}
?>
<br />
<hr />

<h1> Alteration du nom de domaine d'une demande non validée :</h1>

<?php

if(mysqli_num_rows($resultselect) > 0) {
$reqselectval2 = "SELECT type,id_demand,name,Subname,Association,Domain,Mail FROM dc_demands WHERE Validated=0 AND val_mail=1 ORDER BY type ASC, Association DESC;";
$resultselectval2 = mysqli_query($sql_connect, $reqselectval2);
?>
<form action="admin.php" method="post">
<select name="id_demand2">
<?php
while($rowselval = mysqli_fetch_array($resultselectval2,MYSQLI_ASSOC)) {
?>
<option value="<?php echo $rowselval['id_demand']; ?>"><?php echo $rowselval['type']; ?> | <?php echo $rowselval['name']; ?> <?php echo $rowselval['Subname']; ?> | <?php echo $rowselval['Association']; ?> | <?php echo $rowselval['Domain']; ?> | <?php echo $rowselval['Mail']; ?></option>
<?php
}
?>
</select>
<br />
<label>Domaine</label>
<input type="text" name="Domainmod" placeholder="Nom de domaine souhaité" data-minlength="3" required />
<button type="submit">Modifier le domaine</button>
</form>
<?php
if (isset($_POST['id_demand2']) && !empty($_POST['id_demand2']) && isset($_POST['Domainmod']) && !empty($_POST['Domainmod'])) {
		$domain = securite_bdd($_POST['Domainmod']);
		$domain = strtolower($domain);
		$domain = mysqli_real_escape_string($sql_connect,$domain);
		$domain = str_replace('www.','',$domain);
		$domain = 'www.'.$domain;
		$iddemand2 = $_POST['id_demand2'];
		// Requête SQL
		$reqdomainmod = "UPDATE dc_demands SET Domain='$domain' WHERE dc_demands.id_demand=$iddemand2;";
		// Execution SQL
		$resdomainmod = mysqli_query($sql_connect,$reqdomainmod);
		// Echo du travail fait.
		echo 'Domaine modifié - Refraichissement en cours...';
?>
<meta http-equiv="refresh" content="5">
<?php
}

}
else
{
echo 'Pas d\'enregistrements dans la table des demandes de cr&eacute;ation de blogs...';
}
?>
<br />
<hr />

<h1>Selection des demandes avec mail non vérifié : </h1>

<?php
$reqselectmail = "SELECT * FROM dc_demands WHERE dc_demands.val_mail=0 ORDER BY Mail ASC;";
$resultselectmail = mysqli_query($sql_connect, $reqselectmail);
if(mysqli_num_rows($resultselectmail) > 0) {
$reqselectvalmail = "SELECT type,id_demand,name,Subname,Association,Domain,Mail FROM dc_demands WHERE Validated=0 AND val_mail=0 ORDER BY Mail ASC;";
$resultselectvalmail = mysqli_query($sql_connect, $reqselectvalmail);
?>
<form action="admin.php" method="post">
<select name="idmailval_demand">
<?php
while($rowselvalmail = mysqli_fetch_array($resultselectvalmail,MYSQLI_ASSOC)) {
?>
<option value="<?php echo $rowselvalmail['id_demand']; ?>"><?php echo $rowselvalmail['type']; ?> | <?php echo $rowselvalmail['name']; ?> <?php echo $rowselvalmail['Subname']; ?> | <?php echo $rowselvalmail['Association']; ?> | <?php echo $rowselvalmail['Domain']; ?> | <?php echo $rowselvalmail['Mail']; ?></option>
<?php
}
?>
</select>
<button type="submit">Forcer la v&eacute;rification Mail</button>
</form>
<?php
if (isset($_POST['idmailval_demand']) && !empty($_POST['idmailval_demand'])) {
$idvalmail = mysqli_real_escape_string($sql_connect,$_POST['idmailval_demand']); 
//UPDATE SQL
$reqvalmail = "UPDATE dc_demands SET val_mail=1 WHERE dc_demands.id_demand='$idvalmail';";
$resvalmail = mysqli_query($sql_connect,$reqvalmail);
echo 'Mail v&eacute;rifi&eacute; - Refraichissement en cours...';

//REFRESH META
?>
<meta http-equiv="refresh" content="5">
<?php
}
}
else
{
echo 'Pas de mail non v&eacute;rifi&eacute;s dans la table des demandes de cr&eacute;ation de blogs...';
}
?>
<br />
<hr />

</center>
</body>
</html>
