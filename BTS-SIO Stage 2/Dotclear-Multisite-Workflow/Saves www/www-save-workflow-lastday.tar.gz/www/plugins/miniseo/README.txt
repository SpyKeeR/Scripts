miniSEO for Dotclear 2
===============================================================================

Cette version de plugin sert a ajouter dans la page la donn�e meta description,
si le plugin Mymeta n'est pas en place vous les 180 premiers caract�res du billet 
servirons alors � remplir le meta description.

Historique
----------
1.5 Modif mineur de pr�sentation, la description de la homme finie maintenant par ..., un espace ajout� pour PAGE X pour les Categories
1.4 Tronquage de title � 180 caract�res au lieu de 250 avant
1.3 Le plugin est accessible uniquement aux admin, une gestion de page ajout� dans la balise title
1.2 Correction traduction, correction test minimum requis maintenant DC2.0-rc1, correction test presence tag
1.1 Ajout d'une page diagnostique dans l'admin
1.0 Correction comportement avec plugin related (pages connexes)
0.9 Patch provisoire il y avait une grosse erreur dans les pages cat�gories merci llaumgui
0.8 Correction d'une partie du code cod� en dur merci adjaya de l'�quipe DC
0.7 Ajout de la possibilit� de modifier la balise title (uniquement pour les billets)
0.6 Reprise � z�ro pour utiliser dor�navant le Behavior publicHeadContent
0.5 Gestion des page du plugin related (pages connected)
0.4 Gestion maintenant de la page category et page d'accueil
0.3 Couplage avec le plugin http://plugins.dotaddict.org/dc2/details/Mymeta
0.2 Nous ne sommes plus oblig� de placer tpl_use_cache sur non
0.1 Premi�re version
Installation
------------

Voir le mini HOW-TO ici http://www.myouaibe.com/index.php/post/2008/03/26/Plugin-miniSEO


Evolution future
----------------
Ajouter la liste des mots clefs
Ajouter les traductions