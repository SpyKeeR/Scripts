
﻿
CKEDITOR.plugins.setLang('specialchar','zh',{options:'Special Character Options',title:'請選擇特殊符號',toolbar:'插入特殊符號'});