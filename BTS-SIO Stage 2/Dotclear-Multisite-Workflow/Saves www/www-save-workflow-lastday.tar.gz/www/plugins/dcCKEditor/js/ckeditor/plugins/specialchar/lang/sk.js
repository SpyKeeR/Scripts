
﻿
CKEDITOR.plugins.setLang('specialchar','sk',{options:'Možnosti špeciálneho znaku',title:'Výber špeciálneho znaku',toolbar:'Vložiť špeciálny znak'});