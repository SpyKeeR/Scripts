
﻿
CKEDITOR.plugins.setLang('specialchar','ms',{options:'Special Character Options',title:'Sila pilih huruf istimewa',toolbar:'Masukkan Huruf Istimewa'});