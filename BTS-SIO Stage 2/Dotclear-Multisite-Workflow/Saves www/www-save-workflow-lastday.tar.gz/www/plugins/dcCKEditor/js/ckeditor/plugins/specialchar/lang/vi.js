
﻿
CKEDITOR.plugins.setLang('specialchar','vi',{options:'Tùy chọn các ký tự đặc biệt',title:'Hãy chọn ký tự đặc biệt',toolbar:'Chèn ký tự đặc biệt'});