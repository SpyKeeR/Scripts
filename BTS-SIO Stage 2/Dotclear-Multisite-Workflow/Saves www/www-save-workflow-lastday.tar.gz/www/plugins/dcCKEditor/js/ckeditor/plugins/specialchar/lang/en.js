
﻿
CKEDITOR.plugins.setLang('specialchar','en',{options:'Special Character Options',title:'Select Special Character',toolbar:'Insert Special Character'});