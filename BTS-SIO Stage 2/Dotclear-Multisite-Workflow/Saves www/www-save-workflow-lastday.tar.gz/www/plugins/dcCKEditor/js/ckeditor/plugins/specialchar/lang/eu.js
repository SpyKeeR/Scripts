
﻿
CKEDITOR.plugins.setLang('specialchar','eu',{options:'Karaktere Berezien Aukerak',title:'Karaktere Berezia Aukeratu',toolbar:'Txertatu Karaktere Berezia'});