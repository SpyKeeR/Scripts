
﻿
CKEDITOR.plugins.setLang('specialchar','bg',{options:'Опции за специален знак',title:'Избор на специален знак',toolbar:'Вмъкване на специален знак'});