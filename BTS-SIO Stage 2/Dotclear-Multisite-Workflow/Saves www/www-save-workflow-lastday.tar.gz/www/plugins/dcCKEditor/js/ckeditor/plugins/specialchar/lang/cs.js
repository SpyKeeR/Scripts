
﻿
CKEDITOR.plugins.setLang('specialchar','cs',{options:'Nastavení speciálních znaků',title:'Výběr speciálního znaku',toolbar:'Vložit speciální znaky'});