
﻿
CKEDITOR.plugins.setLang('specialchar','he',{options:'אפשרויות תווים מיוחדים',title:'בחירת תו מיוחד',toolbar:'הוספת תו מיוחד'});