
﻿
CKEDITOR.plugins.setLang('specialchar','el',{options:'Επιλογές Ειδικών Χαρακτήρων',title:'Επιλέξτε έναν Ειδικό Χαρακτήρα',toolbar:'Εισαγωγή Ειδικού Χαρακτήρα'});