
﻿
CKEDITOR.plugins.setLang('specialchar','th',{options:'Special Character Options',title:'แทรกตัวอักษรพิเศษ',toolbar:'แทรกตัวอักษรพิเศษ'});