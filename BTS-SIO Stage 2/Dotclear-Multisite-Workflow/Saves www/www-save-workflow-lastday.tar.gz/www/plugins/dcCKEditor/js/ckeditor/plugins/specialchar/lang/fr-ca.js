
﻿
CKEDITOR.plugins.setLang('specialchar','fr-ca',{options:'Option des caractères spéciaux',title:'Sélectionner un caractère spécial',toolbar:'Insérer un caractère spécial'});