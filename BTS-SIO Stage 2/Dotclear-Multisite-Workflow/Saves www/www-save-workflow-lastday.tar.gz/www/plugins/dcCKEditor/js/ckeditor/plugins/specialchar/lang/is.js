
﻿
CKEDITOR.plugins.setLang('specialchar','is',{options:'Special Character Options',title:'Velja tákn',toolbar:'Setja inn merki'});