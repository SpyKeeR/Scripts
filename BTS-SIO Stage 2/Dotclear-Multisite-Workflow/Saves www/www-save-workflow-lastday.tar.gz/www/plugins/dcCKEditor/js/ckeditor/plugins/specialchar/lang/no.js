
﻿
CKEDITOR.plugins.setLang('specialchar','no',{options:'Alternativer for spesialtegn',title:'Velg spesialtegn',toolbar:'Sett inn spesialtegn'});