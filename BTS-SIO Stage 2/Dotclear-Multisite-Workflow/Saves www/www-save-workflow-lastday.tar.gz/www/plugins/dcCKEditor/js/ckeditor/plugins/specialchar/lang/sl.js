
﻿
CKEDITOR.plugins.setLang('specialchar','sl',{options:'Možnosti Posebnega Znaka',title:'Izberi Posebni Znak',toolbar:'Vstavi posebni znak'});