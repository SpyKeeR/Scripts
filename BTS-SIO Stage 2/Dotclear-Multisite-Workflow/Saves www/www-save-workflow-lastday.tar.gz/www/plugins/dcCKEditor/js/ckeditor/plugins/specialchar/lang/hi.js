
﻿
CKEDITOR.plugins.setLang('specialchar','hi',{options:'Special Character Options',title:'विशेष करॅक्टर चुनें',toolbar:'विशेष करॅक्टर इन्सर्ट करें'});