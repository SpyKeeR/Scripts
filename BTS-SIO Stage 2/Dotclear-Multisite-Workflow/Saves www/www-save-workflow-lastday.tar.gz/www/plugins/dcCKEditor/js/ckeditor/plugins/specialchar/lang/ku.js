
﻿
CKEDITOR.plugins.setLang('specialchar','ku',{options:'هەڵبژاردەی نووسەی تایبەتی',title:'هەڵبژاردنی نووسەی تایبەتی',toolbar:'دانانی نووسەی تایبەتی'});