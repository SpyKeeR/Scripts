
﻿
CKEDITOR.plugins.setLang('specialchar','tr',{options:'Özel Karakter Seçenekleri',title:'Özel Karakter Seç',toolbar:'Özel Karakter Ekle'});