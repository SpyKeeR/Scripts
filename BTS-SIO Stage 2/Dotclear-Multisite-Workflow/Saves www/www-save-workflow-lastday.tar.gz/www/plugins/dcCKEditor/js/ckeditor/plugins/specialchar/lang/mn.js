
﻿
CKEDITOR.plugins.setLang('specialchar','mn',{options:'Special Character Options',title:'Онцгой тэмдэгт сонгох',toolbar:'Онцгой тэмдэгт оруулах'});