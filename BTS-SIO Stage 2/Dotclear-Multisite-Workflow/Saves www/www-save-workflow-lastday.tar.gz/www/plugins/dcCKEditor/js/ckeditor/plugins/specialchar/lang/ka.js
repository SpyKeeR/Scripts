
﻿
CKEDITOR.plugins.setLang('specialchar','ka',{options:'სპეციალური სიმბოლოს პარამეტრები',title:'სპეციალური სიმბოლოს არჩევა',toolbar:'სპეციალური სიმბოლოს ჩასმა'});