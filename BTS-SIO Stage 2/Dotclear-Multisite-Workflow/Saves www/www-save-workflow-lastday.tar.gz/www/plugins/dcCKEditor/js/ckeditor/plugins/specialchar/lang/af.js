
﻿
CKEDITOR.plugins.setLang('specialchar','af',{options:'Spesiale karakter-opsies',title:'Kies spesiale karakter',toolbar:'Voeg spesiaale karakter in'});