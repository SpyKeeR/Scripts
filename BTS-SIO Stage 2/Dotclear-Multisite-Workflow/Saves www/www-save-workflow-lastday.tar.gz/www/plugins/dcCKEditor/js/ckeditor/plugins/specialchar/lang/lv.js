
﻿
CKEDITOR.plugins.setLang('specialchar','lv',{options:'Speciālo simbolu uzstādījumi',title:'Ievietot īpašu simbolu',toolbar:'Ievietot speciālo simbolu'});