
﻿
CKEDITOR.plugins.setLang('specialchar','de',{options:'Sonderzeichen Optionen',title:'Sonderzeichen auswählen',toolbar:'Sonderzeichen einfügen/editieren'});