
﻿
CKEDITOR.plugins.setLang('specialchar','pl',{options:'Opcje znaków specjalnych',title:'Wybierz znak specjalny',toolbar:'Wstaw znak specjalny'});