
﻿
CKEDITOR.plugins.setLang('specialchar','ca',{options:'Opcions de caràcters especials',title:'Selecciona el caràcter especial',toolbar:'Insereix caràcter especial'});