
﻿
CKEDITOR.plugins.setLang('specialchar','sq',{options:'Mundësitë për Karaktere Speciale',title:'Përzgjidh Karakter Special',toolbar:'Vendos Karakter Special'});