
﻿
CKEDITOR.plugins.setLang('specialchar','fo',{options:'Møguleikar við serteknum',title:'Vel sertekn',toolbar:'Set inn sertekn'});