
﻿
CKEDITOR.plugins.setLang('specialchar','da',{options:'Muligheder for specialkarakterer',title:'Vælg symbol',toolbar:'Indsæt symbol'});