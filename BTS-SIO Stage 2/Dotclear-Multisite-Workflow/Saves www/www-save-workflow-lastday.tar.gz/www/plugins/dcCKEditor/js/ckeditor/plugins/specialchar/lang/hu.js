
﻿
CKEDITOR.plugins.setLang('specialchar','hu',{options:'Speciális karakter opciók',title:'Speciális karakter választása',toolbar:'Speciális karakter beillesztése'});