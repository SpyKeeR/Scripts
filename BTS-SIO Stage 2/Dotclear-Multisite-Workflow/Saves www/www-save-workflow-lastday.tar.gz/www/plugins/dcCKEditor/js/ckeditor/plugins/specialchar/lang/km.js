
﻿
CKEDITOR.plugins.setLang('specialchar','km',{options:'ជម្រើស​តួ​អក្សរ​ពិសេស',title:'រើស​តួអក្សរ​ពិសេស',toolbar:'បន្ថែមអក្សរពិសេស'});