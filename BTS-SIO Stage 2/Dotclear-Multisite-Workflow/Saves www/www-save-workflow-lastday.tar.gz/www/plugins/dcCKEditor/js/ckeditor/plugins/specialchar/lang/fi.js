
﻿
CKEDITOR.plugins.setLang('specialchar','fi',{options:'Erikoismerkin ominaisuudet',title:'Valitse erikoismerkki',toolbar:'Lisää erikoismerkki'});