
﻿
CKEDITOR.plugins.setLang('specialchar','es',{options:'Opciones de caracteres especiales',title:'Seleccione un caracter especial',toolbar:'Insertar Caracter Especial'});