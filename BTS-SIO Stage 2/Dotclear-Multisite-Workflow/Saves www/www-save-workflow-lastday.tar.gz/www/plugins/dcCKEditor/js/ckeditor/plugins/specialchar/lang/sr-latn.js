
﻿
CKEDITOR.plugins.setLang('specialchar','sr-latn',{options:'Special Character Options',title:'Odaberite specijalni karakter',toolbar:'Unesi specijalni karakter'});