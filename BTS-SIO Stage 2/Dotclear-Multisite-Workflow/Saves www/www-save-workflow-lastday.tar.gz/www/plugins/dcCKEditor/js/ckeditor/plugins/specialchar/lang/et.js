
﻿
CKEDITOR.plugins.setLang('specialchar','et',{options:'Erimärkide valikud',title:'Erimärgi valimine',toolbar:'Erimärgi sisestamine'});