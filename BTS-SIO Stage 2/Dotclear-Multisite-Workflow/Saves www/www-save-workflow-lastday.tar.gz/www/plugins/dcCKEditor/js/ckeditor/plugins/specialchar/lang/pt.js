
﻿
CKEDITOR.plugins.setLang('specialchar','pt',{options:'Opções de caracteres especiais',title:'Selecione um caracter especial',toolbar:'Inserir Caracter Especial'});