
﻿
CKEDITOR.plugins.setLang('specialchar','gl',{options:'Opcións de caracteres especiais',title:'Seleccione un carácter especial',toolbar:'Inserir un carácter especial'});