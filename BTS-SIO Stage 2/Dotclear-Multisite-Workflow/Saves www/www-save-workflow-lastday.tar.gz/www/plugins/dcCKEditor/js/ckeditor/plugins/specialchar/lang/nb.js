
﻿
CKEDITOR.plugins.setLang('specialchar','nb',{options:'Alternativer for spesialtegn',title:'Velg spesialtegn',toolbar:'Sett inn spesialtegn'});