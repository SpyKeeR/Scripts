
﻿
CKEDITOR.plugins.setLang('specialchar','it',{options:'Opzioni carattere speciale',title:'Seleziona carattere speciale',toolbar:'Inserisci carattere speciale'});