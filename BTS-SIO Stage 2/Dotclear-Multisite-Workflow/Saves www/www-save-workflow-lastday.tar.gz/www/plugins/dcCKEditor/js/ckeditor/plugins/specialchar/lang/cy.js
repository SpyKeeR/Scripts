
﻿
CKEDITOR.plugins.setLang('specialchar','cy',{options:'Opsiynau Nodau Arbennig',title:'Dewis Nod Arbennig',toolbar:'Mewnosod Nod Arbennig'});