
﻿
CKEDITOR.plugins.setLang('specialchar','id',{options:'Opsi spesial karakter',title:'Pilih spesial karakter',toolbar:'Sisipkan spesial karakter'});