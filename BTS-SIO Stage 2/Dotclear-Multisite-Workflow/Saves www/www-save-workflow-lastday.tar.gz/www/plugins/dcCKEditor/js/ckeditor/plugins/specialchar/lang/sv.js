
﻿
CKEDITOR.plugins.setLang('specialchar','sv',{options:'Alternativ för utökade tecken',title:'Välj utökat tecken',toolbar:'Klistra in utökat tecken'});