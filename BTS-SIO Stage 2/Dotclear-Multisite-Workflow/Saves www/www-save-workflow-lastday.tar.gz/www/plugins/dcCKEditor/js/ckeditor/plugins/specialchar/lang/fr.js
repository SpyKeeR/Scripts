
﻿
CKEDITOR.plugins.setLang('specialchar','fr',{options:'Options des caractères spéciaux',title:'Sélectionnez un caractère',toolbar:'Insérer un caractère spécial'});