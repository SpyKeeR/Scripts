
﻿
CKEDITOR.plugins.setLang('specialchar','mk',{options:'Special Character Options',title:'Select Special Character',toolbar:'Insert Special Character'});