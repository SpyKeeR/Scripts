
﻿
CKEDITOR.plugins.setLang('specialchar','pt-br',{options:'Opções de Caractere Especial',title:'Selecione um Caractere Especial',toolbar:'Inserir Caractere Especial'});