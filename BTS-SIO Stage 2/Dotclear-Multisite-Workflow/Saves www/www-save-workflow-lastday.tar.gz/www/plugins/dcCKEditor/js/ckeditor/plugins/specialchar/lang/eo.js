
﻿
CKEDITOR.plugins.setLang('specialchar','eo',{options:'Opcioj pri Specialaj Signoj',title:'Selekti Specialan Signon',toolbar:'Enmeti Specialan Signon'});