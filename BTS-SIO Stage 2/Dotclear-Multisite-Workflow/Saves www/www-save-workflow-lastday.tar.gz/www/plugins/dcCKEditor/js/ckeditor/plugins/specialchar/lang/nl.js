
﻿
CKEDITOR.plugins.setLang('specialchar','nl',{options:'Speciale tekens opties',title:'Selecteer speciaal teken',toolbar:'Speciaal teken invoegen'});