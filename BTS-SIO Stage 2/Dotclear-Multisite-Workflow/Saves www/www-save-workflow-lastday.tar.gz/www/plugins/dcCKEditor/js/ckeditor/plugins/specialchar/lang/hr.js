
﻿
CKEDITOR.plugins.setLang('specialchar','hr',{options:'Opcije specijalnih znakova',title:'Odaberite posebni karakter',toolbar:'Ubaci posebne znakove'});