
﻿
CKEDITOR.plugins.setLang('specialchar','bs',{options:'Special Character Options',title:'Izaberi specijalni karakter',toolbar:'Ubaci specijalni karater'});