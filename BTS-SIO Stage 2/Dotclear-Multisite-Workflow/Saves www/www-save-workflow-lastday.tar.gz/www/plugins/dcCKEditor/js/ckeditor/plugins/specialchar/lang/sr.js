
﻿
CKEDITOR.plugins.setLang('specialchar','sr',{options:'Опције специјалног карактера',title:'Одаберите специјални карактер',toolbar:'Унеси специјални карактер'});