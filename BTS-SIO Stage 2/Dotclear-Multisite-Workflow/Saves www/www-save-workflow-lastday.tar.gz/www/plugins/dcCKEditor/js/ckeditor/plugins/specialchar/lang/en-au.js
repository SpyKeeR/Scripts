
﻿
CKEDITOR.plugins.setLang('specialchar','en-au',{options:'Special Character Options',title:'Select Special Character',toolbar:'Insert Special Character'});