
﻿
CKEDITOR.plugins.setLang('specialchar','ro',{options:'Opțiuni caractere speciale',title:'Selectează caracter special',toolbar:'Inserează caracter special'});