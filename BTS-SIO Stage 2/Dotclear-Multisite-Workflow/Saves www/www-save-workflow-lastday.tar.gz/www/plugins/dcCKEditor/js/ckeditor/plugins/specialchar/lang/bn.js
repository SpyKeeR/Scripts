
﻿
CKEDITOR.plugins.setLang('specialchar','bn',{options:'Special Character Options',title:'বিশেষ ক্যারেক্টার বাছাই কর',toolbar:'বিশেষ অক্ষর যুক্ত কর'});