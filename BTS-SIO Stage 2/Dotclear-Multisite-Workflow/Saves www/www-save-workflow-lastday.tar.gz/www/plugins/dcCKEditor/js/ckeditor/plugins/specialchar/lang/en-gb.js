
﻿
CKEDITOR.plugins.setLang('specialchar','en-gb',{options:'Special Character Options',title:'Select Special Character',toolbar:'Insert Special Character'});