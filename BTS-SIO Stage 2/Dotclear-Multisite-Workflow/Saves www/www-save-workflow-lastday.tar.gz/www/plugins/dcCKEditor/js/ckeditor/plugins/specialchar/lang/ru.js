
﻿
CKEDITOR.plugins.setLang('specialchar','ru',{options:'Выбор специального символа',title:'Выберите специальный символ',toolbar:'Вставить специальный символ'});