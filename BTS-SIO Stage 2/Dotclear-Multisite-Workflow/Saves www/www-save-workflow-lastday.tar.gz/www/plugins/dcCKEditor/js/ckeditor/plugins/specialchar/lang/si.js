
﻿
CKEDITOR.plugins.setLang('specialchar','si',{options:'විශේෂ  ගුණාංග වීකල්ප',title:'විශේෂ  ගුණාංග ',toolbar:'විශේෂ ගුණාංග ඇතුලත් '});