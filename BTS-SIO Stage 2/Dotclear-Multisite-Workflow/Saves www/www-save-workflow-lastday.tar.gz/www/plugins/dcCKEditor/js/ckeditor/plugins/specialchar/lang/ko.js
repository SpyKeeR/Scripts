
﻿
CKEDITOR.plugins.setLang('specialchar','ko',{options:'특수문자 옵션',title:'특수문자 선택',toolbar:'특수문자 삽입'});