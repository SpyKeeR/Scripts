
﻿
CKEDITOR.plugins.setLang('specialchar','lt',{options:'Specialaus simbolio nustatymai',title:'Pasirinkite specialų simbolį',toolbar:'Įterpti specialų simbolį'});