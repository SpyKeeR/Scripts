
﻿
CKEDITOR.plugins.setLang('specialchar','ar',{options:'خيارات الأحرف الخاصة',title:'اختر حرف خاص',toolbar:'إدراج  حرف خاص'});